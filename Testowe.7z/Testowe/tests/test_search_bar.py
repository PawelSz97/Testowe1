import sys
import unittest
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
import os

parent_directory = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(parent_directory)
from demoPages.main_page import MainPage

class MainPageTest(unittest.TestCase):

    def setUp(self):
        self.driver = webdriver.Firefox()
        self.driver.get('http://demostore.supersqa.com')
        self.driver.maximize_window()
        self.main_page = MainPage(self.driver)

    def test_search_bar(self):
        search_bar = self.driver.find_element(By.CSS_SELECTOR, '#woocommerce-product-search-field-0')
        search_bar.send_keys('Cap')
        search_bar.send_keys(Keys.ENTER)
        wait = WebDriverWait(self.driver, 10)
        element = wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, '.product_title')))
        text = element.text
        self.assertEqual(text, "Cap")

    def tearDown(self):
        self.driver.quit()

if __name__ == "__main__":
    unittest.main()