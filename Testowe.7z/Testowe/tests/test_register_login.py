import sys
import unittest
from selenium import webdriver
from selenium.webdriver.common.by import By
import time
#sys.path.append("..")
#sys.path.append('/home/tester/Desktop/SeleniumProjektWSB-master/ShopProject/demoPages/main_page.py')
#from demoPages.main_page import MainPage
import os;
parent_directory = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(parent_directory)
from demoPages.main_page import MainPage

class RegisterAndLoginPageTest(unittest.TestCase):

    password_selector = '#password',
    username_login_email_selector = '#username'
    register_password_selector = '#reg_password'
    register_email_selector = '#reg_email'
    password = 'Ala123#@!'
    not_existing_login_email = 'asdasdssw2@wp.pl'
    existing_email = 'wsx@wp.pl'


    def setUp(self):
        self.driver = webdriver.Firefox()
        self.driver.get('http://demostore.supersqa.com')
        self.driver.maximize_window()
        self.main_page = MainPage(self.driver)

        

    def test_register_existing_user(self):
        self.driver.find_element(By.CSS_SELECTOR,'.nav-menu li:nth-child(4)').click() # otwieram account
        register_email = self.driver.find_element(By.CSS_SELECTOR, self.register_email_selector )
        register_email.send_keys(self.existing_email)
        register_password = self.driver.find_element(By.CSS_SELECTOR, self.register_password_selector )
        register_password.send_keys(self.password)
        self.driver.find_element(By.CSS_SELECTOR,'button[value= "Register"]').click() #kilkam przycisk zarejestruj
        acutal_text = self.driver.find_element(By.CSS_SELECTOR, '.woocommerce-error li').text
        self.assertEqual(acutal_text,"Error: An account is already registered with your email address. Please log in.")
        
    def test_login_exisiting_user(self):
        self.driver.find_element(By.CSS_SELECTOR,'.nav-menu li:nth-child(4)').click() # otwieram account
        login_email = self.driver.find_element(By.CSS_SELECTOR, self.username_login_email_selector)
        login_email.send_keys(self.existing_email) 
        login_password = self.driver.find_element(By.CSS_SELECTOR,'.password-input [type ="password"][autocomplete="current-password"]')
        login_password.send_keys(self.password)
        self.driver.find_element(By.CSS_SELECTOR,'.form-row button[name="login"]').click() # klikam zaloguj
        actual_text = self.driver.find_element(By.CSS_SELECTOR,'h1.entry-title').text
        self.assertEqual(actual_text,"My account")


    def test_login_not_exisiting_user(self):
        self.driver.find_element(By.CSS_SELECTOR,'.nav-menu li:nth-child(4)').click() # otwieram account
        login_email = self.driver.find_element(By.CSS_SELECTOR, self.username_login_email_selector)
        login_email.send_keys(self.not_existing_login_email) 
        login_password = self.driver.find_element(By.CSS_SELECTOR,'.password-input [type ="password"][autocomplete="current-password"]')
        login_password.send_keys(self.password)
        self.driver.find_element(By.CSS_SELECTOR,'.form-row button[name="login"]').click() # klikam zaloguj
        actual_text = self.driver.find_element(By.CSS_SELECTOR,'.woocommerce-error li').text
        self.assertEqual(actual_text,"Unknown email address. Check again or try your username.")

    def tearDown(self):
        self.driver.quit()

if __name__ == "__main__":
    unittest.main()