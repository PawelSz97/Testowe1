import sys
import unittest
from selenium import webdriver
from selenium.webdriver.common.by import By
#sys.path.append("..")
#sys.path.append('/home/tester/Desktop/SeleniumProjektWSB-master/ShopProject/demoPages/main_page.py')
#from demoPages.main_page import MainPage
import time
import os;
parent_directory = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(parent_directory)
from demoPages.main_page import MainPage
from demoPages.cart_page import CartPage


class MainPageTest(unittest.TestCase):

    product_selector = '.product-name[data-title= "Product"]'
    expected_text = '$15.00'

    def setUp(self):
        self.driver = webdriver.Firefox()
        self.driver.get('http://demostore.supersqa.com')
        self.driver.maximize_window()
        self.main_page = MainPage(self.driver)
        self.cart_page = CartPage(self.driver)

    def test_check_product_value(self):
        self.main_page.add_album_to_cart()
        self.main_page.open_shopping_cart() ## tutaj sie sypie
        # self.driver.find_element(By.CSS_SELECTOR,'.nav-menu li:nth-child(2)').click() ##otwieram karte
        self.cart_page.veryfi_product_price()
        # element = self.driver.find_element(By.CSS_SELECTOR,'[data-title="Total"] .woocommerce-Price-amount bdi')
        # actual_text = element.text
        # self.assertEqual(actual_text, self.expected_text)
        
    def tearDown(self):
        self.driver.quit()

if __name__ == "__main__":
    unittest.main()