

class SearchBarPage:

    def __init__(self, driver):
        self.driver = driver

        self.product_expcted_name = "Cap"
    